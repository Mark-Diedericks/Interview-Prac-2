import unittest

from test_task1 import TestTask1
from test_task2 import TestTask2
from test_task3 import TestTask3
from test_task4 import TestTask4
from test_task5 import TestTask5
from test_task6 import TestTask6

if __name__ == '__main__':
  unittest.main()
